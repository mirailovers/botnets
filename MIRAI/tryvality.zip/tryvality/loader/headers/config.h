#pragma once

#define HTTP_SERVER "209.141.52.202"
#define HTTP_PORT 80
// replace the ips
#define TFTP_SERVER "209.141.52.202"